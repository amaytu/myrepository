﻿namespace Estacionamento
{
    internal class AddCarForm : IDisposable
    {
        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}