﻿namespace Estacionamento
{
    partial class CadastroDoCarro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            nomeTextBox = new TextBox();
            placaTextBox = new TextBox();
            groupBox1 = new GroupBox();
            botaoOk = new Button();
            dateTimePicker1 = new DateTimePicker();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 21);
            label1.Name = "label1";
            label1.Size = new Size(87, 15);
            label1.TabIndex = 0;
            label1.Text = "Nome do carro";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 71);
            label2.Name = "label2";
            label2.Size = new Size(82, 15);
            label2.TabIndex = 1;
            label2.Text = "placa do carro";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 118);
            label3.Name = "label3";
            label3.Size = new Size(90, 15);
            label3.TabIndex = 2;
            label3.Text = "Data de entrada";
            label3.Click += label3_Click;
            // 
            // nomeTextBox
            // 
            nomeTextBox.Location = new Point(6, 43);
            nomeTextBox.Name = "nomeTextBox";
            nomeTextBox.Size = new Size(224, 23);
            nomeTextBox.TabIndex = 4;
            nomeTextBox.TextChanged += textBox1_TextChanged;
            // 
            // placaTextBox
            // 
            placaTextBox.Location = new Point(6, 89);
            placaTextBox.Name = "placaTextBox";
            placaTextBox.Size = new Size(224, 23);
            placaTextBox.TabIndex = 5;
            placaTextBox.TextChanged += textBox2_TextChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dateTimePicker1);
            groupBox1.Controls.Add(botaoOk);
            groupBox1.Controls.Add(placaTextBox);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(nomeTextBox);
            groupBox1.Location = new Point(12, 28);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(320, 202);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "informacoes do estacionamento";
            // 
            // botaoOk
            // 
            botaoOk.Location = new Point(228, 165);
            botaoOk.Name = "botaoOk";
            botaoOk.Size = new Size(75, 23);
            botaoOk.TabIndex = 9;
            botaoOk.Text = "Ok";
            botaoOk.UseVisualStyleBackColor = true;
            botaoOk.Click += botaoOk_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(6, 136);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 10;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // CadastroDoCarro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(344, 241);
            Controls.Add(groupBox1);
            Name = "CadastroDoCarro";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CadastroDoCarro";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox nomeTextBox;
        private TextBox placaTextBox;
        private GroupBox groupBox1;
        private Button botaoOk;
        private DateTimePicker dateTimePicker1;
    }
}