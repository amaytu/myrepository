﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Estacionamento
{
    public partial class CadastroDoCarro : Form
    {
        public CadastroDoCarro()
        {
            InitializeComponent();
        }

        public string nomeDoCarro { get; set; }
        public string placaDoCarro { get; set; }
        public DateTime horarioEntrada { get; set; }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void botaoOk_Click(object sender, EventArgs e)
        {
            textBox1_TextChanged(sender, e);
            textBox2_TextChanged(sender, e);
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (nomeTextBox.Text.Length > 0)
            {
                nomeDoCarro = nomeTextBox.Text;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (placaTextBox.Text.Length > 0 && placaTextBox.Text.Length <= 7)
            {
                placaDoCarro = placaTextBox.Text;
            }

            else
            {
                MessageBox.Show("a placa do carro deve ter somente 8 digitos");
            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
             horarioEntrada = DateTime.Now;
 
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy HH:mm:ss";
        }
    }
}
