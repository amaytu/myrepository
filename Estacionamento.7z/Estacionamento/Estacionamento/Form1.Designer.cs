﻿namespace Estacionamento
{
    partial class Estacionamento
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            botaoAdicionar = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            dataGridView1 = new DataGridView();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // botaoAdicionar
            // 
            botaoAdicionar.AutoSize = true;
            botaoAdicionar.BackColor = Color.White;
            botaoAdicionar.Location = new Point(479, 323);
            botaoAdicionar.Name = "botaoAdicionar";
            botaoAdicionar.Size = new Size(124, 41);
            botaoAdicionar.TabIndex = 0;
            botaoAdicionar.Text = "Adicionar Carro";
            botaoAdicionar.UseVisualStyleBackColor = false;
            botaoAdicionar.Click += BotaoAdicionar_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonFace;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 79);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(553, 210);
            dataGridView1.TabIndex = 4;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button1
            // 
            button1.BackColor = Color.White;
            button1.Location = new Point(349, 323);
            button1.Name = "button1";
            button1.Size = new Size(124, 41);
            button1.TabIndex = 5;
            button1.Text = "Remover Carro";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Estacionamento
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(615, 372);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(botaoAdicionar);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Name = "Estacionamento";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Estacionamento";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button botaoAdicionar;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private DataGridView dataGridView1;
        private Button button1;
    }
}