using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace Estacionamento
{
    public partial class Estacionamento : Form
    {
        public List<string> Nomes { get; set; }
        public List<string> Placas { get; set; }
        public List<DateTime> HorariosEntrada { get; set; }
        public List<DateTime> HorariosSaida { get; set; }
        public double valorTotal = 0;

        public Estacionamento()
        {
            InitializeComponent();

            Nomes = new List<string>();
            Placas = new List<string>();
            HorariosEntrada = new List<DateTime>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BotaoAdicionar_Click(object sender, EventArgs e)
        {
            CadastroDoCarro cadastroDoCarro = new CadastroDoCarro();
            cadastroDoCarro.ShowDialog();
        }

        private void ListaCarros_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void AdicionarCarro(string nome, string placa, DateTime horarioEntrada)
        {
            Nomes.Add(nome);
            Placas.Add(placa);
            HorariosEntrada.Add(horarioEntrada);
            DatagridviewUsingDataTable();
        }

        public double CalculoAPagar()
        {
            
            double valorHoraInicial = 2; 
            double valorHoraAdicional = 1; 
            double toleranciaMinutosPorHora = 10; 

            for (int i = 0; i < HorariosSaida.Count; i++)
            {
                TimeSpan duracaoEstadia = HorariosSaida[i] - HorariosEntrada[i];

                double horasTotais = (float)duracaoEstadia.TotalHours;
                double valorEstadia = 0;
                
                if (horasTotais <= 1)
                {
                    valorEstadia = valorHoraInicial;
                }
                else
                {
                    double horasComTolerancia = Math.Ceiling(horasTotais - toleranciaMinutosPorHora / 60);
                    valorEstadia = valorHoraInicial + (horasComTolerancia - 1) * valorHoraAdicional;
                }

                valorTotal += valorEstadia;
            }

            return valorTotal;
        }

        private void DatagridviewUsingDataTable()
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("Nome do Carro", typeof(string));
            dt.Columns.Add("Placa do Carro", typeof(string));
            dt.Columns.Add("Data de Entrada", typeof(DateTime));
            dt.Columns.Add("Data de Saida", typeof(DateTime));
            dt.Columns.Add("Valor para pagar", typeof(double));


            for (int i = 0; i < Nomes.Count; i++)
            {
                dt.Rows.Add(Nomes[i], Placas[i], HorariosEntrada[i], HorariosSaida[i],valorTotal);
            }

            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RemoverCarro removerCarro = new RemoverCarro();
            removerCarro.ShowDialog();
        }
    }
}