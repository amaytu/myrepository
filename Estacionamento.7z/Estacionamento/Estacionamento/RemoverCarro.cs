﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estacionamento
{
    public partial class RemoverCarro : Form
    {
        public RemoverCarro()
        {
            InitializeComponent();
        }

        Estacionamento estacionamento = new Estacionamento();
        DateTime horarioSaida = DateTime.Now;

        private void button1_Click(object sender, EventArgs e)
        {
            string placaSaida = txtPlaca.Text;
            for (int i = 0; i < estacionamento.Placas.Count; i++)
            {
                if (placaSaida == estacionamento.Placas[i])
                {
                    estacionamento.HorariosSaida[i] = DateTime.Now;
                    break;
                }

            }
        }
    }
}

